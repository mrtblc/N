﻿using Microsoft.AspNetCore.Mvc;
using MubcoTeknoloji.AdminPanel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MubcoTeknoloji.AdminPanel.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Signin(UserLoginModel model)
        {
            if (model.UserName == "admin" && model.Password == "admin")
                return RedirectToAction("Index", "Home");
            else
                ModelState.AddModelError("", "UserName admin and Password admin");
            return View("Index", model);
        }
    }
}
